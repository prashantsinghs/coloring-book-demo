# coloring
Coloring in Javascript html5-canvas

![demo1.png](https://raw.githubusercontent.com/raksa/coloring/master/demo/demo1.png)